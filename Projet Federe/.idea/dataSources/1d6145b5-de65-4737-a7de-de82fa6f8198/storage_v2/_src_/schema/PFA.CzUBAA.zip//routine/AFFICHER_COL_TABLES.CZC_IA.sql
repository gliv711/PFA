create procedure afficher_col_tables (nom_table IN varchar2) is
 t_count integer;
cursor c is select * from all_tab_columns where table_name = 'nom_table';
begin
t_count := 0;
select count(*) into t_count from all_tables where table_name = 'nom_table';

if(t_count = 1 ) then
    for column in c loop
        dbms_output.put_line(column.column_name);
        if (column.data_type = 'VARCHAR2') then
            dbms_output.put_line(column.data_length);
        end if;
        if (column.data_type = 'NUMBER') then
            dbms_output.put_line(column.data_precision || ' ' || column.data_scale );
        end if;
    end loop;
else 
    dbms_output.put_line('table does not exist');
end if;
end;
/

